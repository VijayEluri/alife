package test.fuzzyea;
import jml.basics.Result;
import java.io.*;

import test.evolution.dfa.DFAEvoResult;

public class DFAScript {

  public static void stat( String path, String file ){
    try{
      int min = 0;
      int max = 0;
      Result[] res = new Result[10];
      int[] m = new int[10];
      for (int i = 0; i < 10; i++) {
        m[i] = i;
        String file_i = path + file + "-" + i + ".txt";
        res[i] = new DFAEvoResult( file_i );
        if( ((DFAEvoResult)res[i]).accuracy < ((DFAEvoResult)res[min]).accuracy ){
          min = i;
        }else{
          if( ((DFAEvoResult)res[i]).accuracy > ((DFAEvoResult)res[max]).accuracy ){
            max = i;
          }
        }
      }

      for( int i=0; i<9; i++ ){
        DFAEvoResult ri = (DFAEvoResult)res[i];
        for( int j=i+1; j<10; j++ ){
          DFAEvoResult rj = (DFAEvoResult)res[j];
          if( ri.accuracy > rj.accuracy ){
            res[i] = rj;
            res[j] = ri;
            ri = rj;
            int t = m[i];
            m[i] = m[j];
            m[j] = t;
          }
        }
      }

//      double median = ((DFAEvoResult)res[4]).accuracy;
      double med1 = ((DFAEvoResult)res[4]).accuracy;
      double med2 = ((DFAEvoResult)res[5]).accuracy;

      double mr = ((DFAEvoResult)res[0]).accuracy;
      double Mr = ((DFAEvoResult)res[9]).accuracy;


      FileWriter output = new FileWriter( path +  file + ".txt" );
      DFAEvoResult avg = (DFAEvoResult)Result.average( res );
      DFAEvoResult std = (DFAEvoResult)Result.stdError(res, avg);
      int n = avg.best.length;
      output.write(avg.accuracy + " " + std.accuracy + " " +  mr + " " + med1 + " " + med2 + " " +  Mr );
      output.write(  " " + min + " " + m[4] + " " + m[5]+ " " + max + "\n");
      for( int i=0; i<n; i++ ){
        output.write(i+" "+avg.best[i]+" "+std.best[i]+"\n");
      }
      output.close();
    }catch( Exception e ){ System.err.println(e.getMessage()); };
  }

  public static void main( String[] argv ){

    stat(argv[0], argv[1]);

//    getSummary( argv[0] );
  }

  public static void getSummary( String path ){
//    int[] dfa_size = new int[]{ 30, 20, 10};
//    String[] bool_val=new String[]{"true","false"};
//    int[] pack_size=new int[]{ 100, 20, 10, 5, 1};
//    int[] pop_size=new int[]{ 1, 5, 10, 20 };
    int[] dfa_size = new int[]{ 20, 10};
    String[] bool_val=new String[]{"true"};
    int[] pack_size=new int[]{ 0 };
    int[] pop_size=new int[]{ 1 };

    for(int i=0; i<dfa_size.length; i++) {
      for(int k=0; k<bool_val.length; k++ ){
        for(int m=0; m<bool_val.length; m++ ){
          for(int j=0; j<pop_size.length; j++){
            for(int n=0; n<pack_size.length; n++ ){
              if( m<1 || n>-1 ){
                String out = path + "haea-dfa=" + dfa_size[i] + "-enc=" +
                    bool_val[k] +
                    "-sort=" + bool_val[m] + "-pop=" + pop_size[j] +
                    "-pack=" + pack_size[n] + ".txt";
                try {
  //                System.out.println( out );
                  BufferedReader reader = new BufferedReader(new FileReader(out));
                  System.out.print(bool_val[k] + " " + bool_val[m] + " " +
                                   pop_size[j] +
                                   " " + pack_size[n] + "  ");

                  System.out.println(reader.readLine());
                  reader.close();
                }
                catch (Exception e) {
                  e.printStackTrace();
                }
              }
            }
          }
        }
      }
    }
  }
}
